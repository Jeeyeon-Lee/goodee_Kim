module dev_java {
	requires java.desktop;
}