package com.step2;

public class K {
	void m() {
		System.out.println("m");
	}
	public static void main(String[] args) {
		//m을 호출하지 않으면 5번은 실행될 기회를 갖지 못함.

	}

}
