package com.step2;

public class Emp {
  private int empno;
  private String ename;
  private double salary;
}
