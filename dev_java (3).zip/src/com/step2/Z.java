package com.step2;

public class Z {
	class Inner {
		
	}
	public static void main(String[] args) {
		Z z  = new Z();
		Inner inner = z.new Inner();

	}

}
