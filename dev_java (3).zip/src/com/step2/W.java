package com.step2;

public class W {

	public static void main(String[] args) {
		String[] s1, s5 = null;
		String s2[], s3 = null;
		s5 = "222";
		s3 = "222";

	}

}
