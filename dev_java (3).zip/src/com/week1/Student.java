package com.week1;

public class Student {
	int html 	= 0;
	int css 	= 0;
	int java 	= 0;
}
