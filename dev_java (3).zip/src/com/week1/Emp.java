package com.week1;

public class Emp {
	//사원번호를 담을 변수 선언
	int 		empno 		= 0;
	//사원이름을 담을 변수 선언
	String ename 		= null;
	String job 		 		= null;
}
// 7566 나신입 마케팅