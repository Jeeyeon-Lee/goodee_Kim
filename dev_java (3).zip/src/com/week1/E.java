package com.week1;

import javax.swing.JFrame;

public class E extends Object{

	public static void main(String[] args) {
		E e = new E();
		JFrame jf = new JFrame();
		System.out.println(e);
		System.out.println(e.toString());
		System.out.println(jf);
		System.out.println(jf.toString());

	}

}
