package com.step4;

public class H {
//사용자정의 클래스와 자바제공클래스 섞어쓰기
//관심사가 변경되었다. - > 클래스 나누어서 연습할것. -> 2개, 3개
//-> 클래스 쪼개기 -> 명분(MVC) -> 자바(스프링) ->  제어역전(역제어), dependency injection(DI)
//-> git공부하자 -나누어 개발하기 -> web개발 -> 클라이언트 사이드개발, 서버사이드 개발
	public static void main(String[] args) {
		String msg = new String("안녕");
		System.out.println(msg);
	}

}
