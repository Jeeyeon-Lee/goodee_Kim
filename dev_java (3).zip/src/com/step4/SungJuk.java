package com.step4;
//계산기 구현하기 - 화면제공합니다. - 사칙연산하기
public class SungJuk {
	String datas[][] = {
			{"나신입", "80", "95","70"},
			{"나초보", "80", "95","70"},
			{"나일등", "80", "95","70"}
	};
	//  총점, 평균, 석차 - 콘솔
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
