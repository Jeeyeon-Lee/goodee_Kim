package com.week3;

public class StringArray {

	public static void main(String[] args) {
		String names2[] = new String[3];
		String names3[] = {"나신입","나잘난","나일등"};
		String names[] =  new String[]{"나신입","나잘난","나일등"};
		for(String name:names) {
			System.out.println(name);
		}

	}

}
