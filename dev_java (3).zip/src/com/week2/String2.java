package com.week2;

public class String2 {

	public static void main(String[] args) {
		String s1 = "";
		String s2 = null;
		System.out.println(s1);//아무것도 . 무슨일이 있었나
		System.out.println(s2);//아무것도 . 무슨일이 있었나
		System.out.println(s1.equals(s2));
		System.out.println("".toString());
		
		//System.out.println(s2.equals(s1));
	}

}
