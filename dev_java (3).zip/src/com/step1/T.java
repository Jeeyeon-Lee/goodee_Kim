package com.step1;

public class T {
	static int x = 3; 
}
