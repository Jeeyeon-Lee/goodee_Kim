package com.step1;

public class MPeople {//사람정보 담는 클래스
	String name="병아리";//고유명사
	int age;//나이
	void go() {
		//메소드의 좌중괄호 우중괄호 사이에서 선언된 변수는 모두 지변이다.
		int age;//지변
	}
}
