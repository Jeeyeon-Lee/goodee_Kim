package com.step1;

public class MPerson {

	public static void main(String[] args) {
		MPeople me = new MPeople();
		//me.name = "토마토";
		System.out.println(me.name);
	}

}
