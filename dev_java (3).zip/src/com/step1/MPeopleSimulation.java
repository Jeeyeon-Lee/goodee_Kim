package com.step1;

public class MPeopleSimulation {

	public static void main(String[] args) {
		MPeople me = new MPeople();
		me.name = "나초보";
		System.out.println(me.name);

	}

}
